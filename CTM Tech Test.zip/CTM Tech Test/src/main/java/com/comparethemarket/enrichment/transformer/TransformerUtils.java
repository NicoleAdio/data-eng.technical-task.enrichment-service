package com.comparethemarket.enrichment.transformer;

import com.comparethemarket.enrichment.domain.input.CustomerEvent;
import java.math.BigDecimal;
import java.util.List;
import lombok.experimental.UtilityClass;

@UtilityClass
public final class TransformerUtils {

	public static BigDecimal calculateAverageSpend(CustomerEvent event) {
		return null;
	}

	public static List<String> getBrands(CustomerEvent purchaseEvent) {
		return null;
	}

}
