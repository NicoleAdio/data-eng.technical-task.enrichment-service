package com.comparethemarket.enrichment;

import com.comparethemarket.enrichment.transformer.TransformerUtils;
import org.junit.Test;

public class TransformerUtilsTest {

	@Test
	public void placeholderTest() {

//		TransformerUtils.calculateAverageSpend();
//		TransformerUtils.getBrands();

	}


}
